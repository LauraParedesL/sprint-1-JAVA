package com.mindhub.homebanking.models;

public enum CardColor {
    GOLD,
    SILVER,
    TITANIUM
}
